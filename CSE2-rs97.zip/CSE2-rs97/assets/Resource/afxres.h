// Quick-and-dirty shim to make CSE2.rc work in newer versions of Visual Studio

#include "windows.h"
